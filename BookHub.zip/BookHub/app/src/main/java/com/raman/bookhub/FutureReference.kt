package com.raman.bookhub

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
//import android.widget.Toolbar
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
/*
class MainActivity : AppCompatActivity() {

    lateinit var drawerLayout : DrawerLayout
    lateinit var coordinatorLayout : CoordinatorLayout
    lateinit var toolbar : Toolbar
    lateinit var frameLayout : FrameLayout
    lateinit var navigationView : NavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawerLayout = findViewById(R.id.drawerLayout)
        coordinatorLayout = findViewById(R.id.coordinatorLayout)
        toolbar = findViewById(R.id.toolbar)
        frameLayout = findViewById(R.id.frame)
        navigationView = findViewById(R.id.navigationView)
        setUpToolbar()

        val actionBarDrawerToggle = ActionBarDrawerToggle(
            this@MainActivity ,
            drawerLayout,
            R.string.open_drawer ,
            R.string.close_drawer
        )

        drawerLayout.addDrawerListener(actionBarDrawerToggle)            //this will set click listener on hamburger icon which is the actionBarToggle
        actionBarDrawerToggle.syncState()                                // what this will do is, when the drawer is outside we will press the hamburger icon, then the drawer will come in
                                                                         // and the icon will change to a back arrow icon


        //         used to add a CLICK LISTENER to the items of the navigation drawer
        navigationView.setNavigationItemSelectedListener {

            when (it.itemId){                    // using "it" will give us the currently selected item
                R.id.dashboard -> {

//                    Toast.makeText(this@MainActivity , "Clicked on Dashboard" , Toast.LENGTH_SHORT).show()    // this line was used in topic 1 videos

                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame , DashboardFragment())
                        .addToBackStack("Dashboard")           // THIS is to store the fragments in Backstack
                        .commit()                                         // this is to apply the above methods

                    drawerLayout.closeDrawers()                      // this is to close the drawers after clicking on the list of menu
                }

                R.id.favourites -> {
//                    Toast.makeText(this@MainActivity , "Clicked on Favourites" , Toast.LENGTH_SHORT).show()
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame , FavouritesFragment())
                        .addToBackStack("Favourites")
                        .commit()
                    drawerLayout.closeDrawers()
                }
                R.id.profile -> {
//                    Toast.makeText(this@MainActivity , "Clicked on Profile" , Toast.LENGTH_SHORT).show()
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame , ProfileFragment())
                        .addToBackStack("Profile")
                        .commit()
                    drawerLayout.closeDrawers()
                }
                R.id.aboutApp -> {
//                    Toast.makeText(this@MainActivity , "Clicked on About App" , Toast.LENGTH_SHORT).show()
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame , AboutFragment())
                        .addToBackStack("About App")
                        .commit()
                    drawerLayout.closeDrawers()
                }
            }
            return@setNavigationItemSelectedListener true

        }


    }

    fun setUpToolbar(){
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Toolbar Title"
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }


    //    ***************************this method is to add CLICK LISTENER to the action bar *********************************
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == android.R.id.home){
            drawerLayout.openDrawer(GravityCompat.START)
        }
        return super.onOptionsItemSelected(item)
    }
}

*/



//***************************************TILL TOPIC 2 VIDEO - 3************************************************





//   ***********************************CONTINUATION*************************
/*
package com.raman.bookhub

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
//import android.widget.Toolbar
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {

    lateinit var drawerLayout : DrawerLayout
    lateinit var coordinatorLayout : CoordinatorLayout
    lateinit var toolbar : Toolbar
    lateinit var frameLayout : FrameLayout
    lateinit var navigationView : NavigationView



    var previousMenuItem : MenuItem? = null



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawerLayout = findViewById(R.id.drawerLayout)
        coordinatorLayout = findViewById(R.id.coordinatorLayout)
        toolbar = findViewById(R.id.toolbar)
        frameLayout = findViewById(R.id.frame)
        navigationView = findViewById(R.id.navigationView)
        setUpToolbar()

//        fun openDashboard(){
//            val fragement = DashboardFragment()
//            val transaction = supportFragmentManager.beginTransaction()
//            transaction.replace(R.id.frame , fragement)
//            transaction.commit()
//            supportActionBar?.title = "Dashboard"
//        }

        openDashboard()

        val actionBarDrawerToggle = ActionBarDrawerToggle(
            this@MainActivity ,
            drawerLayout,
            R.string.open_drawer ,
            R.string.close_drawer
        )
        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()





        navigationView.setNavigationItemSelectedListener {

            if (previousMenuItem != null){
                previousMenuItem?.isChecked = false
            }
            it.isCheckable = true
            it.isChecked = true
            previousMenuItem = it

            when (it.itemId){
                R.id.dashboard -> {


//                    supportFragmentManager.beginTransaction()
//                        .replace(R.id.frame , DashboardFragment())
//                        .addToBackStack("Dashboard")
//                        .commit()
//
//                    supportActionBar?.title = "Dashboard"          // this is to fix the error number 1 in topic 2 video 4


                    openDashboard()
                    drawerLayout.closeDrawers()
                }

                R.id.favourites -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame , FavouritesFragment())
//                        .addToBackStack("Favourites")
                        .commit()

                    supportActionBar?.title = "Favourites"
                    drawerLayout.closeDrawers()
                }
                R.id.profile -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame , ProfileFragment())
//                        .addToBackStack("Profile")
                        .commit()

                    supportActionBar?.title = "Profile"
                    drawerLayout.closeDrawers()
                }
                R.id.aboutApp -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame , AboutFragment())
//                        .addToBackStack("About App")
                        .commit()

                    supportActionBar?.title = "About App"
                    drawerLayout.closeDrawers()
                }
            }
            return@setNavigationItemSelectedListener true

        }


    }

    fun setUpToolbar(){
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Toolbar Title"
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == android.R.id.home){
            drawerLayout.openDrawer(GravityCompat.START)
        }
        return super.onOptionsItemSelected(item)
    }

    fun openDashboard(){
        val fragement = DashboardFragment()
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.frame , fragement)
        transaction.commit()
        supportActionBar?.title = "Dashboard"
        navigationView.setCheckedItem(R.id.dashboard)
    }

    override fun onBackPressed() {
        val frag = supportFragmentManager.findFragmentById(R.id.frame)

        when (frag){
            !is DashboardFragment -> openDashboard()
            else -> super.onBackPressed()
        }
    }
}
// ************************************TILL TOPIC 2********************************************
*/