package com.raman.bookhub.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query


@Dao
interface BookDao {

    @Insert
    fun insertBook(bookEntity: BookEntity)

    @Delete
    fun deleteBook(bookEntity: BookEntity)

    @Query("SELECT * FROM books")     // go to BookEntity.kt and check for tableName = "books"
    fun getAllBooks(): List<BookEntity>
    // check whether a particular book is added to favorites or not.
    // so we can simply check for the book_id in the table and see if it is added to the table or not

    @Query("SELECT * FROM books WHERE book_id = :bookId")
    fun getBookById(bookId : String): BookEntity

}