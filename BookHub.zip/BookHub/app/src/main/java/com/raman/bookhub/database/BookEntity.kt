package com.raman.bookhub.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

// since entities store information in the form of tables, we use data in this class (this will be a data class)


@Entity(tableName = "books")
data class BookEntity (                                                   // adding properties in the primary constructor
    @PrimaryKey val book_id : Int,                                 // book_id will be the primary key since it has all unique values
    @ColumnInfo(name = "book_name")   val bookName   : String,
    @ColumnInfo(name = "book_author") val bookAuthor : String,
    @ColumnInfo(name = "book_price")  val bookPrice  : String,
    @ColumnInfo(name = "book_rating") val bookRating : String,
    @ColumnInfo(name = "book_desc")   val bookDesc   : String,
    @ColumnInfo(name = "book_image")  val bookImage  : String
)

