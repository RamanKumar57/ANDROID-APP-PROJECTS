package com.raman.bookhub.fragment


import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.*
import androidx.fragment.app.Fragment
import android.widget.Button
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.raman.bookhub.R
import com.raman.bookhub.adapter.DashboardRecyclerAdapter
import com.raman.bookhub.model.Book
import com.raman.bookhub.util.ConnectionManager
import org.json.JSONException
import java.util.*
import kotlin.Comparator
import kotlin.collections.HashMap


class DashboardFragment : Fragment() {

    lateinit var recyclerDashboard : RecyclerView

    lateinit var layoutManager : RecyclerView.LayoutManager

    lateinit var btnCheckInternet : Button


        /*                         commented after topic 6 , video 2

    val bookList = arrayListOf(
        "P.S. I Love You",
        "The Great Gatsby",
        "Anna Karenina",
        "Madame Bovary",
        "War and Peace",
        "Lolita",
        "Middle march",
        "The Adventures of Huckleberry Finn",
        "Moby-Dick",
        "The Lord of the Rings"
    )
       */



    lateinit var recyclerAdapter : DashboardRecyclerAdapter

    // added these two lines during topic - 6 , video - 5 (error handling part 2)

    lateinit var progressLayout : RelativeLayout
    lateinit var progressBar : ProgressBar



    val bookInfoList = arrayListOf<Book>()

    //**************added during topic - 10, video - 4 (adding funcitonality to sorting icon)**************

    var ratingComparator = Comparator<Book> { book1, book2 ->

        // last topic of topic - 10 , video - 4 . Check in the 7th page of topic 10

        if (book1.bookRating.compareTo(book2.bookRating, true) == 0){
            // sort according to name if rating is same
            book1.bookName.compareTo(book2.bookName , true)
        }else{
            book1.bookRating.compareTo(book2.bookRating, true)
        }


        // commented this after writing the above if else block
        //book1.bookRating.compareTo(book2.bookRating, true)
    }




                   //         commented after topic 6 , video 2
/*
    val bookInfoList = arrayListOf<Book>(
        //Book("P.S.I love you" , "Rs. 299" , "Cecelia Ahern" , "4.5" , R.drawable.ps_ily),
        Book("1" , "P.S. I Love You" , "Cecilia Ahern" , "4.5" , "Rs.299" , "R.drawable.ps_ily"),
        Book("2" , "The Great Gatsby" , "F.Scott Fitzgerald" , "4.1" , "Rs.399" , "R.drawable.great_gatsby"),
        Book("3" , "Anna Karenina" , "Leo Tolstoy" , "4.3" , "Rs.199" , "R.drawable.anna_kare"),
        Book("4" , "Madame Bovary" , "Gustave Flaubert" , "4.0" , "Rs. 500" , "R.drawable.madame"),
        Book("5" , "War and Peace" , "Leo Tolstoy" , "4.8" , "Rs. 600" , "R.drawable.war and peace"),
        Book("6" , "Lolita" , "Vladimier Nabokov" , "5.0" , "Rs. 300" , "R.drawable.lolita"),
        Book("7" , "Middlemarch" , "George Eliot" , "4.6" , "Rs. 200" , "R.drawable.middlemarch"),
        Book("8" , "The Adventures of Huckleberry Finn" , "Mark Twain" , "4.3" , "Rs. 400" , "R.drawable.adventures_finn"),
        Book("9" , "Moby Dick" , "Herman Melville" , "4.1" , "Rs. 600" , "R.drawable.moby_dick"),
        Book("10" , "The Lord of Rings" , "J.R.R.Tolkien" , "4.9" , "Rs. 700" , "R.drawable.lord_of_rings")

    )
*/




    override fun onCreateView(

        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_dashboard, container, false)

        // *****************  this fun is added in topic - 10 , video - 3 (adding an icon to sort the books)***********
        setHasOptionsMenu(true)


        recyclerDashboard = view.findViewById(R.id.recyclerDashboard)






        btnCheckInternet = view.findViewById(R.id.btnCheckInternet)

        // again these three lines are added during topic - 6 , video - 5 (error handling part 2)

        progressLayout = view.findViewById(R.id.progressLayout)
        progressBar    = view.findViewById(R.id.progressBar)
        progressLayout.visibility = View.VISIBLE


        // adding a click listener
        btnCheckInternet.setOnClickListener{
            if (ConnectionManager().checkConnectivity(activity as Context)){
                // Internet is available
                val dialog = AlertDialog.Builder(activity as Context)
                dialog.setTitle("Success")
                dialog.setMessage("Internet Connection Found")
                dialog.setPositiveButton("OK"){text , listener ->
                    // DO NOTHING
                }

                dialog.setNegativeButton("Cancel"){text, listener ->
                    // DO NOTHING
                }
                dialog.create()
                dialog.show()

            }else{
                val dialog = AlertDialog.Builder(activity as Context)
                dialog.setTitle("Error")
                dialog.setMessage("Internet Connection not Found")
                dialog.setPositiveButton("OK"){text , listener ->
                    // DO NOTHING
                }

                dialog.setNegativeButton("Cancel"){text , listener ->
                    // DO NOTHING
                }
                dialog.create()
                dialog.show()
            }
        }






        layoutManager = LinearLayoutManager(activity)

        // commented after topic - 6 ,video - 3


//        recyclerAdapter = DashboardRecyclerAdapter(activity as Context , bookInfoList)
//
//        recyclerDashboard.adapter = recyclerAdapter
//
//        recyclerDashboard.layoutManager = layoutManager
//
//        recyclerDashboard.addItemDecoration(
//            DividerItemDecoration(
//                recyclerDashboard.context,
//                (layoutManager as LinearLayoutManager).orientation
//            )
//        )



        // TOPIC - 6 , VIDEO - 1 . Sending a request to API to fetch some data

        val queue = Volley.newRequestQueue(activity as Context)

        val url = "http://13.235.250.119/v1/book/fetch_books/"



        //          if else block is from topic - 6 , video - 4 (ERROR HANDLING PART - 1)

        if (ConnectionManager().checkConnectivity(activity as Context)){

            val jsonObjectRequest = object : JsonObjectRequest(Request.Method.GET, url , null ,  Response.Listener{

                //       starting of topic -6, video - 5 (ERROR HANDLING PART - 2)

                try{

                    // Again this line is added during topic - 6 , video - 5 (error handling part 2)
                    progressLayout.visibility = View.GONE

                    val success = it.getBoolean("success")

                    if (success){
                        val data = it.getJSONArray("data")
                        for (i in 0 until data.length()){
                            val bookJsonObject = data.getJSONObject(i)
                            val bookObject = Book(
                                bookJsonObject.getString("book_id"),
                                bookJsonObject.getString("name"),
                                bookJsonObject.getString("author"),
                                bookJsonObject.getString("rating"),
                                bookJsonObject.getString("price"),
                                bookJsonObject.getString("image")
                            )
                            bookInfoList.add(bookObject)        // after this we need to send this list to adapter

                            recyclerAdapter = DashboardRecyclerAdapter(activity as Context , bookInfoList)

                            recyclerDashboard.adapter = recyclerAdapter

                            recyclerDashboard.layoutManager = layoutManager

                            recyclerDashboard.addItemDecoration(
                                DividerItemDecoration(
                                    recyclerDashboard.context,
                                    (layoutManager as LinearLayoutManager).orientation
                                )
                            )
                        }
                    }else{
                        Toast.makeText(activity as Context , "Some Error Occurred!!!" , Toast.LENGTH_SHORT).show()
                    }

                } catch (e:JSONException){
                    Toast.makeText(activity as Context , "Some unexpected error occurred!!!" , Toast.LENGTH_SHORT).show()
                }




/*
                val success = it.getBoolean("success")

                if (success){
                    val data = it.getJSONArray("data")
                    for (i in 0 until data.length()){
                        val bookJsonObject = data.getJSONObject(i)
                        val bookObject = Book(
                            bookJsonObject.getString("book_id"),
                            bookJsonObject.getString("name"),
                            bookJsonObject.getString("author"),
                            bookJsonObject.getString("rating"),
                            bookJsonObject.getString("price"),
                            bookJsonObject.getString("image")
                        )
                        bookInfoList.add(bookObject)        // after this we need to send this list to adapter

                        recyclerAdapter = DashboardRecyclerAdapter(activity as Context , bookInfoList)

                        recyclerDashboard.adapter = recyclerAdapter

                        recyclerDashboard.layoutManager = layoutManager

                        recyclerDashboard.addItemDecoration(
                            DividerItemDecoration(
                                recyclerDashboard.context,
                                (layoutManager as LinearLayoutManager).orientation
                            )
                        )
                    }
                }else{
                    Toast.makeText(activity as Context , "Some Error Occurred!!!" , Toast.LENGTH_SHORT).show()
                }
*/



            } , Response.ErrorListener {

                // HERE WE WILL HANDLE THE ERRORS
                //println("Errors in $it")
                //     topic - 6 , video - 5
                // this if condition was added in topic - 10 , video - 2 to resolve a small error (Don't confuse)

                if (activity != null){
                    Toast.makeText(activity as Context , "Volley error occurred" , Toast.LENGTH_SHORT).show()
                }

                //          THIRD ERROR IS RESOLVED

            }){


                override fun getHeaders() : MutableMap<String , String>{
                    val headers = HashMap<String , String>()
                    headers["Content-type"] = "application/json"
                    headers["token"] = "a91b75750c6aa7"
                    return headers
                }

            }

            queue.add(jsonObjectRequest)

        }else{
            val dialog = AlertDialog.Builder(activity as Context)
            dialog.setTitle("Error")
            dialog.setMessage("Internet Connection not Found")
            dialog.setPositiveButton("OPEN SETTINGS"){text , listener ->
                // DO NOTHING
                val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingsIntent)
                activity?.finish()
            }

            dialog.setNegativeButton("EXIT"){text , listener ->
                // DO NOTHING
                ActivityCompat.finishAffinity(activity as Activity)
            }
            dialog.create()
            dialog.show()
        }







/*                       I HAVE COMMENTED THIS AFTER TOPIC - 6 , VIDEO - 4 (ERROR HANDLING PART - 1)

        val jsonObjectRequest = object : JsonObjectRequest(Request.Method.GET, url , null ,  Response.Listener{

            // HERE WE WILL HANDLE THE RESPONSE
            //println("Response is $it")

            //                                      topic - 6 , video - 3

            val success = it.getBoolean("success")

            if (success){
                val data = it.getJSONArray("data")
                for (i in 0 until data.length()){
                    val bookJsonObject = data.getJSONObject(i)
                    val bookObject = Book(
                        bookJsonObject.getString("book_id"),
                        bookJsonObject.getString("name"),
                        bookJsonObject.getString("author"),
                        bookJsonObject.getString("rating"),
                        bookJsonObject.getString("price"),
                        bookJsonObject.getString("image")
                    )
                    bookInfoList.add(bookObject)        // after this we need to send this list to adapter

                    recyclerAdapter = DashboardRecyclerAdapter(activity as Context , bookInfoList)

                    recyclerDashboard.adapter = recyclerAdapter

                    recyclerDashboard.layoutManager = layoutManager

                    recyclerDashboard.addItemDecoration(
                        DividerItemDecoration(
                            recyclerDashboard.context,
                            (layoutManager as LinearLayoutManager).orientation
                        )
                    )
                }
            }else{
                Toast.makeText(activity as Context , "Some Error Occurred!!!" , Toast.LENGTH_SHORT).show()
            }

        } , Response.ErrorListener {

            // HERE WE WILL HANDLE THE ERRORS
            println("Errors in $it")

        }){

            // WRITING CODE TO SEND THE CONTENT OF THE HEADER TO API

            override fun getHeaders() : MutableMap<String , String>{
                val headers = HashMap<String , String>()
                headers["Content-type"] = "application/json"
                headers["token"] = "a91b75750c6aa7"                               //9bf534118365f1
                return headers
            }

        }

        queue.add(jsonObjectRequest)                  // in topic 6 , video - 2
*/
        return view
    }



    // *****************  this fun is added in topic - 10 , video - 3 (adding an icon to sort the books)***********
    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        inflater?.inflate(R.menu.menu_dashboard , menu)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item?.itemId
        if (id == R.id.action_sort){
            Collections.sort(bookInfoList , ratingComparator)
            bookInfoList.reverse()
        }

        recyclerAdapter.notifyDataSetChanged()


        return super.onOptionsItemSelected(item)
    }



}
