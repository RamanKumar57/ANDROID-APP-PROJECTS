package com.raman.bookhub.fragment


import android.content.Context
import android.os.AsyncTask
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.GridLayout
import android.widget.ProgressBar
import android.widget.RelativeLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.raman.bookhub.R
import com.raman.bookhub.adapter.FavouriteRecyclerAdapter
import com.raman.bookhub.database.BookDatabase
import com.raman.bookhub.database.BookEntity


class FavouritesFragment : Fragment() {

    // declaring all the views of fragment_favourites.xml file

    lateinit var recyclerFavourite : RecyclerView
    lateinit var progressLayout : RelativeLayout
    lateinit var progressBar : ProgressBar
    lateinit var layoutManager : RecyclerView.LayoutManager
    lateinit var recyclerAdapter: FavouriteRecyclerAdapter

    //   creating a variable to store the BookList

    var dbBookList = listOf<BookEntity>()



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        // put the return statement in variable view and return view.
        // Then initialize the variables below

        val view = inflater.inflate(R.layout.fragment_favourites, container, false)

        recyclerFavourite = view.findViewById(R.id.recyclerFavourite)
        progressLayout = view.findViewById(R.id.progressLayout)
        progressBar = view.findViewById(R.id.progressBar)

        // initializing layoutManager for the recycler view
        // we use GridLayoutManager here

        layoutManager = GridLayoutManager(activity as Context , 2)

        // Now we will save the data that we get from the database in this variable dbBookList
        // here we are using activity as Context instead of applicationContext because "a fragment cannot directly access
        // the applicationContext"

        dbBookList = RetrieveFavourites(activity as Context).execute().get()

        if (activity != null){
            progressLayout.visibility = View.GONE
            recyclerAdapter = FavouriteRecyclerAdapter(activity as Context , dbBookList)
            recyclerFavourite.adapter = recyclerAdapter
            recyclerFavourite.layoutManager = layoutManager
        }



        return view
    }




    class RetrieveFavourites(val context : Context) : AsyncTask<Void , Void , List<BookEntity>>(){
        override fun doInBackground(vararg p0: Void?): List<BookEntity> {
            val db = Room.databaseBuilder(context , BookDatabase::class.java , "books-db").build()
            return db.bookDao().getAllBooks()
        }

    }


}
