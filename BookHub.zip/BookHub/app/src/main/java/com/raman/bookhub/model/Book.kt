package com.raman.bookhub.model

data class Book(
    val bookId : String,                 // topic - 6, video - 2
    val bookName : String,
    val bookAuthor : String,
    val bookRating : String,
    val bookPrice : String,             // topic - 6, video - 2
    val bookImage : String              // changed from Int ot String in topic - 6, video - 3
)